// Portable type declarations for `@omnyo/plugin-sdk`. Private
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring another private workspace package.
//
// The upstream source is preserved for selected merge integration:
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';

declare const experimental_providerUsageSourceV1: {
    readonly usageListMethod: "provider-usage.v1.listResources";
    readonly usageFetchMethod: "provider-usage.v1.getResource";
    readonly usageSourceRpcContract: {
        readonly "provider-usage.v1.listResources": {
            readonly input: z.ZodObject<{}, z.core.$strip>;
            readonly output: z.ZodObject<{
                label: z.ZodOptional<z.ZodString>;
                resources: z.ZodArray<z.ZodObject<{
                    accountKey: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                    id: z.ZodString;
                    label: z.ZodString;
                    providerId: z.ZodString;
                    scope: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        kind: z.ZodLiteral<"shared">;
                    }, z.core.$strip>, z.ZodObject<{
                        hostId: z.ZodString;
                        hostName: z.ZodString;
                        kind: z.ZodLiteral<"host">;
                    }, z.core.$strip>], "kind">;
                }, z.core.$strip>>;
            }, z.core.$strip>;
            readonly experimental_description: "Cheap complete inventory of resources owned by this source. Reads local metadata only; never refreshes quota or contacts providers. IDs are stable and source-local. Resource order is display order. Shared label preserves empty groups. Resources may disappear between list and fetch.";
        };
        readonly "provider-usage.v1.getResource": {
            readonly input: z.ZodObject<{
                refresh: z.ZodBoolean;
                resourceId: z.ZodString;
            }, z.core.$strip>;
            readonly output: z.ZodObject<{
                accountKey: z.ZodDefault<z.ZodNullable<z.ZodString>>;
                observedAt: z.ZodNullable<z.ZodNumber>;
                usage: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    accountEmail: z.ZodNullable<z.ZodString>;
                    plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        multiplier: z.ZodNullable<z.ZodNumber>;
                    }, z.core.$strip>>>;
                    planLabel: z.ZodNullable<z.ZodString>;
                    status: z.ZodLiteral<"ok">;
                    windows: z.ZodArray<z.ZodObject<{
                        cost: z.ZodNullable<z.ZodObject<{
                            limitUsdCents: z.ZodNumber;
                            usedUsdCents: z.ZodNumber;
                        }, z.core.$strip>>;
                        id: z.ZodString;
                        kind: z.ZodDefault<z.ZodEnum<{
                            "five-hour": "five-hour";
                            custom: "custom";
                            daily: "daily";
                            weekly: "weekly";
                        }>>;
                        label: z.ZodString;
                        model: z.ZodNullable<z.ZodString>;
                        resetsAt: z.ZodNullable<z.ZodString>;
                        usedPercent: z.ZodNumber;
                    }, z.core.$strip>>;
                }, z.core.$strip>, z.ZodObject<{
                    accountEmail: z.ZodNullable<z.ZodString>;
                    plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        multiplier: z.ZodNullable<z.ZodNumber>;
                    }, z.core.$strip>>>;
                    planLabel: z.ZodNullable<z.ZodString>;
                    status: z.ZodLiteral<"not_installed">;
                }, z.core.$strip>, z.ZodObject<{
                    accountEmail: z.ZodNullable<z.ZodString>;
                    plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        multiplier: z.ZodNullable<z.ZodNumber>;
                    }, z.core.$strip>>>;
                    planLabel: z.ZodNullable<z.ZodString>;
                    status: z.ZodLiteral<"unauthenticated">;
                }, z.core.$strip>, z.ZodObject<{
                    accountEmail: z.ZodNullable<z.ZodString>;
                    plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        multiplier: z.ZodNullable<z.ZodNumber>;
                    }, z.core.$strip>>>;
                    planLabel: z.ZodNullable<z.ZodString>;
                    status: z.ZodLiteral<"expired">;
                }, z.core.$strip>, z.ZodObject<{
                    accountEmail: z.ZodNullable<z.ZodString>;
                    message: z.ZodString;
                    plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        multiplier: z.ZodNullable<z.ZodNumber>;
                    }, z.core.$strip>>>;
                    planLabel: z.ZodNullable<z.ZodString>;
                    status: z.ZodLiteral<"error">;
                }, z.core.$strip>], "status">;
            }, z.core.$strip>;
            readonly experimental_description: "Returns actual usage for exactly one listed resource, even when refresh is false. False permits cached observations; true requests a fresh attempt. Never collects other resources as a side effect. A removed resource fails the RPC; consumers relist. Per-account authentication and collection failures are usage states. observedAt is the last successful measurement time.";
        };
    };
    readonly usageMeasurementSchema: z.ZodObject<{
        accountKey: z.ZodDefault<z.ZodNullable<z.ZodString>>;
        observedAt: z.ZodNullable<z.ZodNumber>;
        usage: z.ZodDiscriminatedUnion<[z.ZodObject<{
            accountEmail: z.ZodNullable<z.ZodString>;
            plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                multiplier: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strip>>>;
            planLabel: z.ZodNullable<z.ZodString>;
            status: z.ZodLiteral<"ok">;
            windows: z.ZodArray<z.ZodObject<{
                cost: z.ZodNullable<z.ZodObject<{
                    limitUsdCents: z.ZodNumber;
                    usedUsdCents: z.ZodNumber;
                }, z.core.$strip>>;
                id: z.ZodString;
                kind: z.ZodDefault<z.ZodEnum<{
                    "five-hour": "five-hour";
                    custom: "custom";
                    daily: "daily";
                    weekly: "weekly";
                }>>;
                label: z.ZodString;
                model: z.ZodNullable<z.ZodString>;
                resetsAt: z.ZodNullable<z.ZodString>;
                usedPercent: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            accountEmail: z.ZodNullable<z.ZodString>;
            plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                multiplier: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strip>>>;
            planLabel: z.ZodNullable<z.ZodString>;
            status: z.ZodLiteral<"not_installed">;
        }, z.core.$strip>, z.ZodObject<{
            accountEmail: z.ZodNullable<z.ZodString>;
            plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                multiplier: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strip>>>;
            planLabel: z.ZodNullable<z.ZodString>;
            status: z.ZodLiteral<"unauthenticated">;
        }, z.core.$strip>, z.ZodObject<{
            accountEmail: z.ZodNullable<z.ZodString>;
            plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                multiplier: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strip>>>;
            planLabel: z.ZodNullable<z.ZodString>;
            status: z.ZodLiteral<"expired">;
        }, z.core.$strip>, z.ZodObject<{
            accountEmail: z.ZodNullable<z.ZodString>;
            message: z.ZodString;
            plan: z.ZodDefault<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                multiplier: z.ZodNullable<z.ZodNumber>;
            }, z.core.$strip>>>;
            planLabel: z.ZodNullable<z.ZodString>;
            status: z.ZodLiteral<"error">;
        }, z.core.$strip>], "status">;
    }, z.core.$strip>;
    readonly usagePlanSchema: z.ZodObject<{
        id: z.ZodString;
        multiplier: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>;
    readonly usageResourceListSchema: z.ZodObject<{
        label: z.ZodOptional<z.ZodString>;
        resources: z.ZodArray<z.ZodObject<{
            accountKey: z.ZodDefault<z.ZodNullable<z.ZodString>>;
            id: z.ZodString;
            label: z.ZodString;
            providerId: z.ZodString;
            scope: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"shared">;
            }, z.core.$strip>, z.ZodObject<{
                hostId: z.ZodString;
                hostName: z.ZodString;
                kind: z.ZodLiteral<"host">;
            }, z.core.$strip>], "kind">;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    readonly usageWindowKindSchema: z.ZodEnum<{
        "five-hour": "five-hour";
        custom: "custom";
        daily: "daily";
        weekly: "weekly";
    }>;
};

export { experimental_providerUsageSourceV1 };
