// Portable type declarations for `@omnyo/plugin-sdk`. Private
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring another private workspace package.
//
// The upstream source is preserved for selected merge integration:
// and read the real source: https://github.com/get-bb/bb

import { QueryClient } from '@tanstack/react-query';

/** Primitive scope parts; include every filter, route and permission scope used by load. */
type PluginResourceKey = readonly (string | number | boolean | null)[];
interface PluginResourceOptions<T> {
    key: PluginResourceKey;
    /** Read-only loader. Mutations remain explicit RPC calls. */
    load(): Promise<T>;
    enabled?: boolean;
    /** Milliseconds before a revisit revalidates. Defaults to Infinity (explicit invalidation). */
    staleTime?: number;
}
interface PluginResourceState<T> {
    data: T | undefined;
    error: unknown;
    status: "error" | "idle" | "loading" | "success";
    isRefreshing: boolean;
    /** Shares an existing request; retains the previous successful value. */
    refresh(): Promise<T | undefined>;
    /** Marks this scope stale and reloads active observers without clearing data. */
    invalidate(): void;
}

/** Host-owned identity includes the plugin generation; QueryClient owns the session. */
declare function usePluginResourceQuery<T>(options: PluginResourceOptions<T>, identity: readonly string[], queryClient: QueryClient): PluginResourceState<T>;

export { usePluginResourceQuery };
