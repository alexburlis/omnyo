// Portable type declarations for `@omnyo/plugin-sdk`. Private
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring another private workspace package.
//
// The upstream source is preserved for selected merge integration:
// and read the real source: https://github.com/get-bb/bb

declare function isComposerDraftEmpty(text: string, attachmentCount: number): boolean;

export { isComposerDraftEmpty };
