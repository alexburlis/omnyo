// Portable type declarations for `@omnyo/plugin-sdk`. Private
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring another private workspace package.
//
// The upstream source is preserved for selected merge integration:
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';
import { ChildProcess } from 'node:child_process';
import { Readable } from 'node:stream';

/**
 * The validator-neutral subset of Standard Schema v1 used by plugin contracts.
 * Zod 4 schemas implement this interface directly; other validators can do
 * the same without becoming part of Omnyo's public protocol.
 */
interface StandardSchemaV1<Input = unknown, Output = Input> {
    readonly "~standard": {
        readonly version: 1;
        readonly vendor: string;
        readonly validate: (value: unknown) => StandardSchemaV1Result<Output> | Promise<StandardSchemaV1Result<Output>>;
        readonly jsonSchema?: {
            readonly input: (options: {
                target: string;
            }) => Record<string, unknown>;
            readonly output: (options: {
                target: string;
            }) => Record<string, unknown>;
        };
        readonly types?: {
            readonly input: Input;
            readonly output: Output;
        };
    };
}
type StandardSchemaV1Result<Output> = {
    readonly value: Output;
    readonly issues?: undefined;
} | {
    readonly issues: readonly StandardSchemaV1Issue[];
};
interface StandardSchemaV1Issue {
    readonly message: string;
    readonly path?: PropertyKey | readonly (PropertyKey | {
        readonly key: PropertyKey;
    })[];
}
type StandardSchemaV1InferInput<Schema extends StandardSchemaV1> = NonNullable<Schema["~standard"]["types"]>["input"];
type StandardSchemaV1InferOutput<Schema extends StandardSchemaV1> = NonNullable<Schema["~standard"]["types"]>["output"];
interface PluginRpcMethodContract<InputSchema extends StandardSchemaV1 = StandardSchemaV1, OutputSchema extends StandardSchemaV1 = StandardSchemaV1> {
    readonly experimental_description?: string;
    /** Include this fast local read in threads.get with experimental_pluginData; input is {threadId}. */
    readonly experimental_threadBootstrap?: true;
    /** Include a side-effect-free local admission read in the thread bootstrap; input is {thread:{id,status},host:{id,name}|null}, output is {action:"proceed"}|{action:"wait",reason:string}. Core uses this hint without executing dispatch hooks. */
    readonly experimental_dispatchReadiness?: true;
    /** Stable host-control contract shared by caller and retiring worker; change the key when input, output or meaning becomes incompatible. */
    readonly experimental_hostReplacementKey?: string;
    readonly input: InputSchema;
    readonly output: OutputSchema;
}
type PluginRpcContract = Readonly<Record<string, PluginRpcMethodContract>>;

interface ExperimentalHostSignalContract<PayloadSchema extends StandardSchemaV1 = StandardSchemaV1> {
    readonly payload: PayloadSchema;
}
type ExperimentalHostSignals = Readonly<Record<string, ExperimentalHostSignalContract>>;
interface ExperimentalHostPaths {
    /** Persistent directory scoped to this plugin on this daemon. */
    readonly dataDir: string;
    /** Temporary directory scoped to this worker process. */
    readonly tempDir: string;
}
type ExperimentalHostWatchChangeType = "create" | "delete" | "update";
interface ExperimentalHostWatchChange {
    readonly path: string;
    readonly type: ExperimentalHostWatchChangeType;
}
type ExperimentalHostWatchEvent = {
    readonly kind: "changed";
    readonly changes: readonly ExperimentalHostWatchChange[];
} | {
    readonly kind: "rescan-required";
} | {
    readonly kind: "watch-error";
    readonly message: string;
};
interface ExperimentalHostWatchOptions {
    /** Absolute directory observed by the daemon's native watcher service. */
    readonly rootPath: string;
    /** Root-relative ignore entries using the native watcher syntax. */
    readonly ignoredPaths?: readonly string[];
    /** Quiet period before one coalesced delivery. Defaults to 75 ms. */
    readonly debounceMs?: number;
    /** Maximum time changes may wait. Defaults to 500 ms. */
    readonly maxWaitMs?: number;
}
interface ExperimentalHostWatchSubscription {
    dispose(): Promise<void>;
}
interface ExperimentalHostWorkerLease {
    /** Release this worker-retention lease. Safe to call more than once. */
    dispose(): Promise<void>;
}
type ExperimentalHostWatchListener = (event: ExperimentalHostWatchEvent) => void | Promise<void>;
interface ExperimentalHostRpcContext<Signals extends ExperimentalHostSignals = {}> {
    /** Aborted when this request is cancelled or its worker is disposed. */
    readonly signal: AbortSignal;
    /** Aborted once for the lifetime of this worker process. */
    readonly lifecycle: {
        readonly signal: AbortSignal;
    };
    readonly experimental_paths: ExperimentalHostPaths;
    /** Publish a validated, ephemeral event to this plugin's server entry. */
    experimental_emitSignal<SignalName extends keyof Signals & string>(signal: SignalName, payload: StandardSchemaV1InferInput<Signals[SignalName]["payload"]>): Promise<void>;
    /** Observe raw filesystem changes through the daemon's native watcher. */
    experimental_watch(options: ExperimentalHostWatchOptions, listener: ExperimentalHostWatchListener): Promise<ExperimentalHostWatchSubscription>;
    /**
     * Keep this worker alive after the current call finishes. Active calls and
     * filesystem watches already retain it; use this only for other background
     * work. The daemon may stop an unretained worker after an idle period.
     *
     * When the plugin is updated, a machine whose worker holds a lease keeps that
     * worker running until its own work releases every lease, for at most 25
     * hours, and starts the new version afterwards; other machines switch at
     * once. Methods with a matching `experimental_hostReplacementKey` in both
     * caller and retained worker contracts can continue controlling existing
     * work. Other calls fail with code `plugin_host_replacing`; old-generation
     * signals are dropped. The version key promises compatible input, output
     * and behavior, and must change when that promise no longer holds. Missing
     * keys never permit forwarding. Disabling, removing or safe mode still
     * stops the worker at once.
     */
    experimental_retainWorker(): ExperimentalHostWorkerLease;
}
type ExperimentalHostRpcHandlers<Contract extends PluginRpcContract, Signals extends ExperimentalHostSignals = {}> = {
    [MethodName in keyof Contract]: (input: StandardSchemaV1InferOutput<Contract[MethodName]["input"]>, context: ExperimentalHostRpcContext<Signals>) => StandardSchemaV1InferInput<Contract[MethodName]["output"]> | Promise<StandardSchemaV1InferInput<Contract[MethodName]["output"]>>;
};
interface ExperimentalHostEntry<Contract extends PluginRpcContract = PluginRpcContract, Signals extends ExperimentalHostSignals = {}> {
    readonly experimental_apiVersion: 1;
    readonly contract: Contract;
    readonly experimental_signals?: Signals;
    readonly handlers: ExperimentalHostRpcHandlers<Contract, Signals>;
    readonly dispose?: () => void | Promise<void>;
}
/** Define the single host executable exported by `omnyo.host`. */
declare function experimental_defineHostEntry<const Contract extends PluginRpcContract, const Signals extends ExperimentalHostSignals = {}>(args: {
    contract: Contract;
    experimental_signals?: Signals;
    handlers: ExperimentalHostRpcHandlers<Contract, Signals>;
    dispose?: () => void | Promise<void>;
}): ExperimentalHostEntry<Contract, Signals>;

/** The input form a resolver writes: the options optional, filled per side by the normalizer. */
declare const providerResolvedNativeRootInputSchema: z.ZodObject<{
    ancestors: z.ZodOptional<z.ZodBoolean>;
    fallbackName: z.ZodOptional<z.ZodString>;
    namePrefix: z.ZodOptional<z.ZodString>;
    origin: z.ZodEnum<{
        project: "project";
        user: "user";
    }>;
    path: z.ZodString;
    recursive: z.ZodOptional<z.ZodBoolean>;
    shape: z.ZodOptional<z.ZodEnum<{
        "command-file": "command-file";
        "skill-file": "skill-file";
        commands: "commands";
        skill: "skill";
        skills: "skills";
    }>>;
    skipIfManifest: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
type ProviderResolvedNativeRootInput = z.input<typeof providerResolvedNativeRootInputSchema>;
declare const providerResolvedNativeRootsSchema: z.ZodObject<{
    commands: z.ZodArray<z.ZodObject<{
        ancestors: z.ZodBoolean;
        fallbackName: z.ZodOptional<z.ZodString>;
        namePrefix: z.ZodString;
        origin: z.ZodEnum<{
            project: "project";
            user: "user";
        }>;
        path: z.ZodString;
        recursive: z.ZodBoolean;
        shape: z.ZodEnum<{
            "command-file": "command-file";
            "skill-file": "skill-file";
            commands: "commands";
            skill: "skill";
            skills: "skills";
        }>;
        skipIfManifest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    skills: z.ZodArray<z.ZodObject<{
        ancestors: z.ZodBoolean;
        fallbackName: z.ZodOptional<z.ZodString>;
        namePrefix: z.ZodString;
        origin: z.ZodEnum<{
            project: "project";
            user: "user";
        }>;
        path: z.ZodString;
        recursive: z.ZodBoolean;
        shape: z.ZodEnum<{
            "command-file": "command-file";
            "skill-file": "skill-file";
            commands: "commands";
            skill: "skill";
            skills: "skills";
        }>;
        skipIfManifest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    watchPaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
type ProviderResolvedNativeRoots = z.infer<typeof providerResolvedNativeRootsSchema>;

/**
 * The host RPC a provider plugin implements when its declaration sets
 * `experimental_resolvesNativeRoots`. Core calls `resolveNativeRoots` on the
 * workspace host each time it lists a provider's commands or skills (cached
 * briefly per host and workspace) and scans the returned roots beside the
 * declared ones. The plugin answers from the host's own files — a moved
 * config directory, installed vendor plugins, config-file skill entries —
 * and decides each root's origin: a project-scoped vendor plugin is
 * `project`, a home-directory entry is `user`.
 *
 * Paths are host-absolute without dot segments. A root's `shape` says how the
 * daemon reads it; the defaults (`skills` for the skills side, `commands` for
 * the commands side) are filled by the contract. A thrown error or a
 * malformed answer is logged by core and yields no resolved roots for that
 * listing; it never fails the listing. A side longer than
 * `PROVIDER_RESOLVED_NATIVE_ROOTS_MAX` is cut to the cap, not refused.
 *
 * The contract validates the whole answer at once, so one root the contract
 * refuses (a vendor plugin whose name cannot be a name prefix, say) would
 * cost the user every other root. A resolver runs its answer through
 * `experimental_filterResolvedNativeRoots` before it returns: each root is
 * judged on its own, a refused one is dropped with a warning, and the rest
 * stand.
 */

declare const experimental_nativeRootsResolveInputSchema: z.ZodObject<{
    cwd: z.ZodNullable<z.ZodString>;
    providerId: z.ZodString;
}, z.core.$strict>;
type ExperimentalNativeRootsResolveInput = z.infer<typeof experimental_nativeRootsResolveInputSchema>;
type ResolvedRootSide = "commands" | "skills";
/** What a resolver returns: the normalized roots, defaults filled per side, each side cut to the cap. */
declare const experimental_nativeRootsResolveOutputSchema: z.ZodPipe<z.ZodPipe<z.ZodObject<{
    commands: z.ZodOptional<z.ZodArray<z.ZodObject<{
        ancestors: z.ZodOptional<z.ZodBoolean>;
        fallbackName: z.ZodOptional<z.ZodString>;
        namePrefix: z.ZodOptional<z.ZodString>;
        origin: z.ZodEnum<{
            project: "project";
            user: "user";
        }>;
        path: z.ZodString;
        recursive: z.ZodOptional<z.ZodBoolean>;
        shape: z.ZodOptional<z.ZodEnum<{
            "command-file": "command-file";
            "skill-file": "skill-file";
            commands: "commands";
            skill: "skill";
            skills: "skills";
        }>>;
        skipIfManifest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    skills: z.ZodOptional<z.ZodArray<z.ZodObject<{
        ancestors: z.ZodOptional<z.ZodBoolean>;
        fallbackName: z.ZodOptional<z.ZodString>;
        namePrefix: z.ZodOptional<z.ZodString>;
        origin: z.ZodEnum<{
            project: "project";
            user: "user";
        }>;
        path: z.ZodString;
        recursive: z.ZodOptional<z.ZodBoolean>;
        shape: z.ZodOptional<z.ZodEnum<{
            "command-file": "command-file";
            "skill-file": "skill-file";
            commands: "commands";
            skill: "skill";
            skills: "skills";
        }>>;
        skipIfManifest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    watchPaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>, z.ZodTransform<{
    skills: {
        path: string;
        origin: "project" | "user";
        recursive: boolean;
        ancestors: boolean;
        namePrefix: string;
        shape: "command-file" | "commands" | "skill" | "skill-file" | "skills";
        fallbackName?: string | undefined;
        skipIfManifest?: string | undefined;
    }[];
    commands: {
        path: string;
        origin: "project" | "user";
        recursive: boolean;
        ancestors: boolean;
        namePrefix: string;
        shape: "command-file" | "commands" | "skill" | "skill-file" | "skills";
        fallbackName?: string | undefined;
        skipIfManifest?: string | undefined;
    }[];
    watchPaths?: string[] | undefined;
}, {
    skills?: {
        path: string;
        origin: "project" | "user";
        recursive?: boolean | undefined;
        ancestors?: boolean | undefined;
        namePrefix?: string | undefined;
        shape?: "command-file" | "commands" | "skill" | "skill-file" | "skills" | undefined;
        fallbackName?: string | undefined;
        skipIfManifest?: string | undefined;
    }[] | undefined;
    commands?: {
        path: string;
        origin: "project" | "user";
        recursive?: boolean | undefined;
        ancestors?: boolean | undefined;
        namePrefix?: string | undefined;
        shape?: "command-file" | "commands" | "skill" | "skill-file" | "skills" | undefined;
        fallbackName?: string | undefined;
        skipIfManifest?: string | undefined;
    }[] | undefined;
    watchPaths?: string[] | undefined;
}>>, z.ZodObject<{
    commands: z.ZodArray<z.ZodObject<{
        ancestors: z.ZodBoolean;
        fallbackName: z.ZodOptional<z.ZodString>;
        namePrefix: z.ZodString;
        origin: z.ZodEnum<{
            project: "project";
            user: "user";
        }>;
        path: z.ZodString;
        recursive: z.ZodBoolean;
        shape: z.ZodEnum<{
            "command-file": "command-file";
            "skill-file": "skill-file";
            commands: "commands";
            skill: "skill";
            skills: "skills";
        }>;
        skipIfManifest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    skills: z.ZodArray<z.ZodObject<{
        ancestors: z.ZodBoolean;
        fallbackName: z.ZodOptional<z.ZodString>;
        namePrefix: z.ZodString;
        origin: z.ZodEnum<{
            project: "project";
            user: "user";
        }>;
        path: z.ZodString;
        recursive: z.ZodBoolean;
        shape: z.ZodEnum<{
            "command-file": "command-file";
            "skill-file": "skill-file";
            commands: "commands";
            skill: "skill";
            skills: "skills";
        }>;
        skipIfManifest: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    watchPaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>>;
type ExperimentalNativeRootsResolveOutput = ProviderResolvedNativeRoots;
/** The input form a handler writes (options optional). */
type ExperimentalNativeRootsResolveAnswer = z.input<typeof experimental_nativeRootsResolveOutputSchema>;
/** One root `experimental_filterResolvedNativeRoots` refused, and why. */
interface ExperimentalDroppedNativeRoot {
    side: ResolvedRootSide;
    path: string;
    reason: string;
}
interface ExperimentalFilteredNativeRoots<Skill extends ProviderResolvedNativeRootInput, Command extends ProviderResolvedNativeRootInput> {
    /** The roots that passed, each side cut to the cap, in the order given. */
    answer: {
        skills: Skill[];
        commands: Command[];
        watchPaths?: string[];
    };
    dropped: ExperimentalDroppedNativeRoot[];
    /** How many roots the cap cut from each side. */
    truncated: {
        skills: number;
        commands: number;
    };
}
/**
 * Judge each root of an answer on its own against the contract, drop the
 * ones it refuses, and cut each side to `PROVIDER_RESOLVED_NATIVE_ROOTS_MAX`
 * (the first roots stay). `warn` is called once per dropped root and once
 * per cut side, with the path and the reason — once for the worker's
 * lifetime per (side, path, reason), so a persistent bad root does not flood
 * the host diagnostics. A resolver calls this on its
 * answer before it returns, so one odd vendor plugin cannot void the listing.
 * The reason lists the field-level issues when any field is malformed; the
 * cross-field rules are judged only on a root whose fields all parse.
 */
declare function experimental_filterResolvedNativeRoots<Skill extends ProviderResolvedNativeRootInput, Command extends ProviderResolvedNativeRootInput>(answer: {
    readonly skills?: readonly Skill[];
    readonly commands?: readonly Command[];
    readonly watchPaths?: readonly string[];
}, options: {
    warn: (message: string) => void;
    /** Warned (side, path, reason) keys; defaults to a set that lives as long as the worker. */
    warned?: Set<string>;
}): ExperimentalFilteredNativeRoots<Skill, Command>;
declare const experimental_nativeRootsHostContract: {
    readonly resolveNativeRoots: {
        readonly input: z.ZodObject<{
            cwd: z.ZodNullable<z.ZodString>;
            providerId: z.ZodString;
        }, z.core.$strict>;
        readonly output: z.ZodPipe<z.ZodPipe<z.ZodObject<{
            commands: z.ZodOptional<z.ZodArray<z.ZodObject<{
                ancestors: z.ZodOptional<z.ZodBoolean>;
                fallbackName: z.ZodOptional<z.ZodString>;
                namePrefix: z.ZodOptional<z.ZodString>;
                origin: z.ZodEnum<{
                    project: "project";
                    user: "user";
                }>;
                path: z.ZodString;
                recursive: z.ZodOptional<z.ZodBoolean>;
                shape: z.ZodOptional<z.ZodEnum<{
                    "command-file": "command-file";
                    "skill-file": "skill-file";
                    commands: "commands";
                    skill: "skill";
                    skills: "skills";
                }>>;
                skipIfManifest: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            skills: z.ZodOptional<z.ZodArray<z.ZodObject<{
                ancestors: z.ZodOptional<z.ZodBoolean>;
                fallbackName: z.ZodOptional<z.ZodString>;
                namePrefix: z.ZodOptional<z.ZodString>;
                origin: z.ZodEnum<{
                    project: "project";
                    user: "user";
                }>;
                path: z.ZodString;
                recursive: z.ZodOptional<z.ZodBoolean>;
                shape: z.ZodOptional<z.ZodEnum<{
                    "command-file": "command-file";
                    "skill-file": "skill-file";
                    commands: "commands";
                    skill: "skill";
                    skills: "skills";
                }>>;
                skipIfManifest: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            watchPaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodTransform<{
            skills: {
                path: string;
                origin: "project" | "user";
                recursive: boolean;
                ancestors: boolean;
                namePrefix: string;
                shape: "command-file" | "commands" | "skill" | "skill-file" | "skills";
                fallbackName?: string | undefined;
                skipIfManifest?: string | undefined;
            }[];
            commands: {
                path: string;
                origin: "project" | "user";
                recursive: boolean;
                ancestors: boolean;
                namePrefix: string;
                shape: "command-file" | "commands" | "skill" | "skill-file" | "skills";
                fallbackName?: string | undefined;
                skipIfManifest?: string | undefined;
            }[];
            watchPaths?: string[] | undefined;
        }, {
            skills?: {
                path: string;
                origin: "project" | "user";
                recursive?: boolean | undefined;
                ancestors?: boolean | undefined;
                namePrefix?: string | undefined;
                shape?: "command-file" | "commands" | "skill" | "skill-file" | "skills" | undefined;
                fallbackName?: string | undefined;
                skipIfManifest?: string | undefined;
            }[] | undefined;
            commands?: {
                path: string;
                origin: "project" | "user";
                recursive?: boolean | undefined;
                ancestors?: boolean | undefined;
                namePrefix?: string | undefined;
                shape?: "command-file" | "commands" | "skill" | "skill-file" | "skills" | undefined;
                fallbackName?: string | undefined;
                skipIfManifest?: string | undefined;
            }[] | undefined;
            watchPaths?: string[] | undefined;
        }>>, z.ZodObject<{
            commands: z.ZodArray<z.ZodObject<{
                ancestors: z.ZodBoolean;
                fallbackName: z.ZodOptional<z.ZodString>;
                namePrefix: z.ZodString;
                origin: z.ZodEnum<{
                    project: "project";
                    user: "user";
                }>;
                path: z.ZodString;
                recursive: z.ZodBoolean;
                shape: z.ZodEnum<{
                    "command-file": "command-file";
                    "skill-file": "skill-file";
                    commands: "commands";
                    skill: "skill";
                    skills: "skills";
                }>;
                skipIfManifest: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            skills: z.ZodArray<z.ZodObject<{
                ancestors: z.ZodBoolean;
                fallbackName: z.ZodOptional<z.ZodString>;
                namePrefix: z.ZodString;
                origin: z.ZodEnum<{
                    project: "project";
                    user: "user";
                }>;
                path: z.ZodString;
                recursive: z.ZodBoolean;
                shape: z.ZodEnum<{
                    "command-file": "command-file";
                    "skill-file": "skill-file";
                    commands: "commands";
                    skill: "skill";
                    skills: "skills";
                }>;
                skipIfManifest: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            watchPaths: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
    };
};
type ExperimentalNativeRootsHostContract = typeof experimental_nativeRootsHostContract;

/** One root of a `resolveNativeRoots` answer, in the form a handler writes. */
type ResolvedRoot = NonNullable<ExperimentalNativeRootsResolveAnswer["skills"]>[number];
type ResolvedRootOrigin = "project" | "user";
/** The two sides of a `resolveNativeRoots` answer, each path once per side. */
interface ExperimentalVendorPluginRoots {
    skills: ResolvedRoot[];
    commands: ResolvedRoot[];
}
/** One installed vendor plugin in the Claude plugin layout. */
interface ExperimentalVendorPlugin {
    /** The plugin's root directory (the one holding its manifest), host-absolute. */
    rootPath: string;
    /**
     * The plugin's name: every root is prefixed `<name>:`, and a root
     * `SKILL.md` is named after it when the file's frontmatter names none. A
     * name that cannot be a name prefix costs the plugin its own roots at
     * `experimental_filterResolvedNativeRoots`, not the rest of the answer.
     */
    name: string;
    /** `user` for a personal install, `project` for one the workspace holds. */
    origin: ResolvedRootOrigin;
    /**
     * The manifest's `skills` entries, relative to the root, in the manifest's
     * own form (one path or a list). An absolute or escaping entry is ignored.
     */
    skills?: string | readonly string[];
    /** The manifest's `commands` entries, in the same form. */
    commands?: string | readonly string[];
}
interface ExperimentalVendorPluginRootsArgs {
    /** The plugins in answer order; the first to claim a path keeps it. */
    plugins: readonly ExperimentalVendorPlugin[];
    /**
     * The plugin layout. `claude` lists the conventional roots — the root
     * `SKILL.md`, `skills/` and `commands/` — and then the manifest's entries,
     * each directory read flat: a manifest directory that holds `SKILL.md`
     * itself is one skill. `grok` lists the manifest's entries only, each
     * directory read recursively.
     */
    layout: "claude" | "grok";
}
interface ExperimentalClaudePluginRootsArgs {
    /**
     * The workspace, or null when Omnyo lists without one: project- and
     * local-scoped installs and the project skills directory's plugins count
     * only for the workspace that holds them.
     */
    cwd: string | null;
    /** The host user's home directory. */
    homeDir: string;
    /** The host environment; only `CLAUDE_CONFIG_DIR` is read. */
    env: Readonly<Record<string, string | undefined>>;
}
interface ExperimentalClaudePluginRoots extends ExperimentalVendorPluginRoots {
    /**
     * The Claude config directory the registry was read from:
     * `CLAUDE_CONFIG_DIR` (absolute, `~`-relative, or relative to the home
     * directory), else `~/.claude`. A resolver that also lists the directory's
     * own `skills` and `commands` takes it from here, so both agree.
     */
    claudeDir: string;
}
/**
 * The skill and command roots of the given plugins, in the given order, each
 * prefixed with its plugin's name. In the `claude` layout a plugin
 * contributes its root `SKILL.md` (named after the plugin when the file's
 * frontmatter has no name), `skills/`, `commands/`, then the manifest's
 * `skills` and `commands` entries; in the `grok` layout the manifest's
 * entries only, each directory recursive. A missing component is skipped; a
 * path answered twice is kept for the first plugin that named it.
 */
declare function experimental_resolveVendorPluginRoots(args: ExperimentalVendorPluginRootsArgs): Promise<ExperimentalVendorPluginRoots>;
/**
 * The roots of every enabled Claude plugin on this host, for one workspace.
 * Claude Code records installs in `<claudeDir>/plugins/installed_plugins.json`
 * and switches them in its settings (`enabledPlugins`: user, then the
 * workspace's `settings.json`, then `settings.local.json`; a manifest's
 * `defaultEnabled` decides an unlisted plugin). A `managed` or `user` install
 * is a user root; a `project` or `local` install counts only when the
 * workspace contains it, and is then a project root. An install whose
 * directory is gone is read from the plugin's cache directory. Plugins
 * dropped into the project and user `skills` directories follow. Each
 * plugin's roots come from `experimental_resolveVendorPluginRoots`
 * (`claude` layout), prefixed `<plugin>:`.
 */
declare function experimental_resolveClaudePluginRoots(args: ExperimentalClaudePluginRootsArgs): Promise<ExperimentalClaudePluginRoots>;

type PortableChildProcess = ChildProcess;
interface PortablePipedSpawnRequest {
    command: string;
    args: string[];
    cwd?: string;
    detached?: boolean;
    env?: NodeJS.ProcessEnv;
}
interface PortableOutputChildProcess extends PortableChildProcess {
    stdin: null;
    stdout: Readable;
    stderr: Readable;
}
declare function spawnPortableOutputProcess(request: PortablePipedSpawnRequest): PortableOutputChildProcess;

type VcsProcessPriority = "background" | "interactive" | "status";
interface VcsProcessOptions {
    priority?: VcsProcessPriority;
    signal?: AbortSignal;
    slots?: number;
}
type Command = "gh" | "git";
declare function runVcsProcess<T>(command: Command, args: readonly string[], operation: () => Promise<T>, options?: VcsProcessOptions): Promise<T>;

interface ProcessWithCwd {
    pid: number;
    cwd: string;
}
interface KillProcessesWithCwdUnderArgs {
    directories: readonly string[];
    graceMs?: number;
}
declare function killProcessesWithCwdUnder(args: KillProcessesWithCwdUnderArgs): Promise<ProcessWithCwd[]>;

interface SanitizeInheritedChildProcessEnvArgs {
    env: NodeJS.ProcessEnv;
    shellPath?: string;
}
declare function sanitizeInheritedChildProcessEnv(args: SanitizeInheritedChildProcessEnvArgs): NodeJS.ProcessEnv;

type Origin = "host-worker" | "provider-bridge";
type ProcessPrivateTempInspection = {
    allocationId: string;
    pluginId: string;
    origin: Origin;
    tempDir: string;
    status: "active" | "held" | "recoverable" | "removed";
    reason: string;
    sizeBytes: number | null;
};

type StorageAdmissionRequest = {
  directory: string;
  expectedBytes: number;
  minimumFreeBytes: number;
};

type StorageAdmission = StorageAdmissionRequest & {
  filesystemDirectory: string;
  availableBytes: number;
  requiredBytes: number;
};

type DirectoryProcessInspection = {
    kind: "idle";
} | {
    kind: "busy";
    message: string;
} | {
    kind: "unknown";
    message: string;
};
type DirectoryProcessInspector = (directory: string, signal?: AbortSignal) => Promise<DirectoryProcessInspection>;
declare const inspectDirectoryProcesses: DirectoryProcessInspector;

/**
 * Kills every process whose working directory is at or under any of `directories`,
 * SIGTERM first and SIGKILL after the grace, for a provider tearing down a
 * workspace it made. Plugins built against SDK 0.6.26 or earlier that still pass
 * `{ directory }` keep working at runtime. Experimental: see docs/api_to_audit.md.
 */
declare function experimental_killProcessesWithCwdUnder(args: Parameters<typeof killProcessesWithCwdUnder>[0]): ReturnType<typeof killProcessesWithCwdUnder>;

declare const request: z.ZodObject<{
    directory: z.ZodString;
    expectedBytes: z.ZodNumber;
    minimumFreeBytes: z.ZodNumber;
}, z.core.$strict>;
type ExperimentalStorageAdmissionRequest = z.input<typeof request>;
type ExperimentalStorageAdmission = StorageAdmission;
declare function experimental_assertStorageAdmission(input: ExperimentalStorageAdmissionRequest): Promise<ExperimentalStorageAdmission>;

declare const inspectionOptions: z.ZodObject<{
    budgetSeconds: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
declare const recoveryOptions: z.ZodObject<{
    budgetSeconds: z.ZodOptional<z.ZodNumber>;
    limit: z.ZodOptional<z.ZodNumber>;
    maxBytes: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
type ExperimentalProcessPrivateTempInspection = ProcessPrivateTempInspection;
type ExperimentalProcessPrivateTempInspectOptions = z.input<typeof inspectionOptions>;
type ExperimentalProcessPrivateTempRecoveryOptions = z.input<typeof recoveryOptions>;
declare function experimental_inspectProcessPrivateTemps(options?: ExperimentalProcessPrivateTempInspectOptions): Promise<ExperimentalProcessPrivateTempInspection[]>;
declare function experimental_recoverProcessPrivateTemps(options?: ExperimentalProcessPrivateTempRecoveryOptions): Promise<ExperimentalProcessPrivateTempInspection[]>;

/**
 * What the operating system reports about a running process. `command` is its
 * full command line, or null when the OS does not expose it. `startedAt` is its
 * start time in epoch milliseconds, accurate to about a second on POSIX, or null
 * when it cannot be read.
 */
interface ExperimentalProcessIdentity {
    command: string | null;
    startedAt: number | null;
}
/**
 * Reads a running process's command line and approximate start time, or null
 * when the process is gone or cannot be inspected, so a host entry can confirm
 * a recorded PID still belongs to the process it launched before signalling
 * it. Uses `ps` on POSIX and PowerShell CIM on Windows. Experimental: see
 * docs/api_to_audit.md.
 */
declare function experimental_readProcessIdentity(pid: number): Promise<ExperimentalProcessIdentity | null>;

export { experimental_assertStorageAdmission, experimental_defineHostEntry, experimental_filterResolvedNativeRoots, inspectDirectoryProcesses as experimental_inspectDirectoryProcesses, experimental_inspectProcessPrivateTemps, experimental_killProcessesWithCwdUnder, experimental_nativeRootsHostContract, experimental_nativeRootsResolveInputSchema, experimental_nativeRootsResolveOutputSchema, experimental_readProcessIdentity, experimental_recoverProcessPrivateTemps, experimental_resolveClaudePluginRoots, experimental_resolveVendorPluginRoots, runVcsProcess as experimental_runVcsProcess, sanitizeInheritedChildProcessEnv as experimental_sanitizeInheritedChildProcessEnv, spawnPortableOutputProcess as experimental_spawnPortableOutputProcess };
export type { ExperimentalClaudePluginRoots, ExperimentalClaudePluginRootsArgs, DirectoryProcessInspection as ExperimentalDirectoryProcessInspection, DirectoryProcessInspector as ExperimentalDirectoryProcessInspector, ExperimentalDroppedNativeRoot, ExperimentalFilteredNativeRoots, ExperimentalHostEntry, ExperimentalHostPaths, ExperimentalHostRpcContext, ExperimentalHostRpcHandlers, ExperimentalHostSignalContract, ExperimentalHostSignals, ExperimentalHostWatchChange, ExperimentalHostWatchChangeType, ExperimentalHostWatchEvent, ExperimentalHostWatchListener, ExperimentalHostWatchOptions, ExperimentalHostWatchSubscription, ExperimentalHostWorkerLease, ExperimentalNativeRootsHostContract, ExperimentalNativeRootsResolveAnswer, ExperimentalNativeRootsResolveInput, ExperimentalNativeRootsResolveOutput, ExperimentalProcessIdentity, ExperimentalProcessPrivateTempInspectOptions, ExperimentalProcessPrivateTempInspection, ExperimentalProcessPrivateTempRecoveryOptions, SanitizeInheritedChildProcessEnvArgs as ExperimentalSanitizeInheritedChildProcessEnvArgs, ExperimentalStorageAdmission, ExperimentalStorageAdmissionRequest, VcsProcessOptions as ExperimentalVcsProcessOptions, VcsProcessPriority as ExperimentalVcsProcessPriority, ExperimentalVendorPlugin, ExperimentalVendorPluginRoots, ExperimentalVendorPluginRootsArgs };
