// Portable type declarations for `@omnyo/plugin-sdk`. Private
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring another private workspace package.
//
// The upstream source is preserved for selected merge integration:
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';
import { ExperimentalSidebarFooterActionContext, ExperimentalSidebarFooterItemRegistration, PluginHomepageSectionRegistration, PluginSettingsSectionRegistration, ExperimentalAppOverlayRegistration, ExperimentalSidebarFooterCardRegistration, ExperimentalTitleBarCenterRegistration, PluginNavPanelRegistration, PluginThreadPanelActionRegistration, PluginNewThreadPanelActionRegistration, ComposerCustomization, PluginPendingInteractionRegistration, PluginSidebarFooterActionRegistration, PluginThreadListRegistration, PluginThreadHeaderActionRegistration, ExperimentalThreadCompanionRegistration, PluginThreadViewRegistration, PluginThreadActionRegistration, ExperimentalPluginBrowserToolbarActionRegistration, PluginFileOpenerRegistration, PluginSourceCodeRendererRegistration, PluginDiffRendererRegistration, PluginMessageDirectiveRegistration, ExperimentalCodeFenceRendererRegistration, PluginMessageActionRegistration, PluginCommandRegistration, ExperimentalComposerCommandRegistration, PluginProviderIconRegistration, ExperimentalIconRegistration, PluginTimelineRendererRegistration, PluginEnvironmentProviderInputsRegistration, PluginMachineProviderInputsRegistration, PluginContentScriptRegistration, PluginAppDefinition } from '@omnyo/plugin-sdk';

type ThreadListIndicatorKind = "background-agent" | "background-command" | "callback-waiting" | "dependency-failed" | "draft" | "external" | "goal" | "input-welcome" | "none" | "open" | "plan-mode" | "queued-failed" | "queued-waiting" | "ready-to-archive" | "runtime" | "unread-error" | "unread-success" | "waiting-for-input" | "workflow" | "working-draft";

/**
 * A name the host resolves to a glyph, in this order: a name any plugin
 * registered with `app.experimental_icons.register()`, then a built-in Omnyo icon
 * name (`"Zap"`), then a namespaced `"<pluginId>/<name>"` glyph naming an
 * entry of that plugin's manifest `omnyo.branding.experimental_icons` map. A
 * registration therefore shadows a built-in, and either shadows a declared
 * icon of the same name. Names that resolve to none of the three fall back to
 * the surface's generic icon.
 *
 * Declared icons and registrations are one vocabulary here: the same name
 * works in `experimental_Icon`, in every field below, and — for a declared
 * icon — in the tool, provider and bridge-row declarations that accept one.
 * Declared icons need no frontend bundle and survive the plugin being stopped;
 * registrations can be any React component but live only while the plugin's
 * app bundle is loaded.
 */
type IconName = string;
/**
 * The glyph mapped from the server-owned work summary. Read unreadness from
 * `isUnread` independently. Local drafts may decorate the glyph without
 * changing work state or archive eligibility.
 */
type PluginSidebarThreadIndicator = ThreadListIndicatorKind;
/** One project in the sidebar's live view. */
interface ExperimentalProjectSidebarMenuItem {
    id: string;
    label: string;
    icon?: IconName;
    destructive?: boolean;
    run(): void | Promise<void>;
}
interface ExperimentalProjectSidebarItem {
    id: string;
    label: string;
    icon: IconName;
    href: string;
    threadId?: string;
    status?: {
        icon: IconName;
        label: string;
    };
    indicator?: PluginSidebarThreadIndicator;
    count?: number;
    unread?: boolean;
    children?: readonly ExperimentalProjectSidebarItem[];
    onRename?: (label: string) => void | Promise<void>;
    onReorder?: (orderedChildIds: readonly string[]) => void | Promise<void>;
    onDrop?: (itemId: string) => void | Promise<void>;
    menuItems?: readonly ExperimentalProjectSidebarMenuItem[];
}
interface ExperimentalProjectSidebarGroup {
    /** Host-stamped owner identity; providers omit this field. */
    key?: string;
    projectId: string;
    items: readonly ExperimentalProjectSidebarItem[];
}
interface ExperimentalProjectSidebarItemsRegistration {
    id: string;
    useItems(context: {
        projects: readonly PluginSidebarProject[];
    }): readonly ExperimentalProjectSidebarGroup[];
}
interface PluginSidebarProject {
    id: string;
    name: string;
    /** True for the implicit personal project. */
    isPersonal: boolean;
    /** The app-relative URL of the project's compose screen. */
    href: string;
    /** The app-relative URL of the project's settings page. */
    settingsHref: string;
}

type ExperimentalSidebarFooterCommandKind = "close" | "open" | "toggle";
interface ExperimentalSidebarFooterRuntimeSnapshot {
    command: {
        sequence: number;
        kind: ExperimentalSidebarFooterCommandKind;
    } | null;
}
interface ExperimentalSidebarFooterItemRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ExperimentalSidebarFooterRuntimeSnapshot;
    acknowledgeCommand(sequence: number): void;
}
type CollectedExperimentalSidebarFooterItem = ExperimentalSidebarFooterItemRegistration & {
    runtime: ExperimentalSidebarFooterItemRuntime;
};
type CollectedManagedSidebarFooterItem = CollectedExperimentalSidebarFooterItem & {
    source: "experimental_sidebarFooter";
};
interface CollectedCompatibilitySidebarFooterItem {
    source: "sidebarFooterAction";
    id: string;
    label: string;
    icon: string;
    kind: "action";
    onActivate(context: ExperimentalSidebarFooterActionContext): void | Promise<void>;
    runtime: ExperimentalSidebarFooterItemRuntime;
}
type CollectedSidebarFooterItem = CollectedCompatibilitySidebarFooterItem | CollectedManagedSidebarFooterItem;
declare function adaptSidebarFooterAction(registration: PluginSidebarFooterActionRegistration): CollectedCompatibilitySidebarFooterItem;
type CollectedPluginProviderIconRegistration = Omit<PluginProviderIconRegistration, "providerKind"> & {
    providerKind: PluginProviderIconRegistration["providerKind"] | "all";
};
/** Validated registrations produced by one plugin app setup execution. */
declare const commandShortcutSchema: z.ZodObject<{
    alt: z.ZodDefault<z.ZodBoolean>;
    control: z.ZodDefault<z.ZodBoolean>;
    key: z.ZodString;
    meta: z.ZodDefault<z.ZodBoolean>;
    mod: z.ZodDefault<z.ZodBoolean>;
    shift: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
type CollectedCommandShortcut = z.infer<typeof commandShortcutSchema> | null;
type CollectedPluginCommandRegistration = (Omit<PluginCommandRegistration, "defaultShortcut"> & {
    target: "app";
    defaultShortcut: CollectedCommandShortcut;
}) | (Omit<ExperimentalComposerCommandRegistration, "defaultShortcut"> & {
    target: "composer";
    defaultShortcut: CollectedCommandShortcut;
});
interface CollectedPluginAppRegistrations {
    projectSidebarItems: ExperimentalProjectSidebarItemsRegistration[];
    homepageSections: PluginHomepageSectionRegistration[];
    settingsSections: PluginSettingsSectionRegistration[];
    appOverlays: ExperimentalAppOverlayRegistration[];
    sidebarFooterCards: ExperimentalSidebarFooterCardRegistration[];
    titleBarCenters: ExperimentalTitleBarCenterRegistration[];
    navPanels: PluginNavPanelRegistration[];
    threadPanelActions: PluginThreadPanelActionRegistration[];
    newThreadPanelActions: PluginNewThreadPanelActionRegistration[];
    composerCustomizations: ComposerCustomization[];
    pendingInteractions: PluginPendingInteractionRegistration[];
    sidebarFooterActions: PluginSidebarFooterActionRegistration[];
    experimentalSidebarFooterItems: CollectedExperimentalSidebarFooterItem[];
    threadLists: PluginThreadListRegistration[];
    threadHeaderActions: PluginThreadHeaderActionRegistration[];
    threadCompanions: ExperimentalThreadCompanionRegistration[];
    threadViews: PluginThreadViewRegistration[];
    threadActions: PluginThreadActionRegistration<unknown>[];
    browserToolbarActions: ExperimentalPluginBrowserToolbarActionRegistration[];
    fileOpeners: PluginFileOpenerRegistration[];
    sourceCodeRenderers: PluginSourceCodeRendererRegistration[];
    diffRenderers: PluginDiffRendererRegistration[];
    messageDirectives: PluginMessageDirectiveRegistration[];
    codeFenceRenderers: ExperimentalCodeFenceRendererRegistration[];
    messageActions: PluginMessageActionRegistration[];
    commandPaletteActions: CollectedPluginCommandRegistration[];
    providerIcons: CollectedPluginProviderIconRegistration[];
    icons: ExperimentalIconRegistration[];
    timelineRenderers: PluginTimelineRendererRegistration[];
    environmentProviderInputs: PluginEnvironmentProviderInputsRegistration[];
    machineProviderInputs: PluginMachineProviderInputsRegistration[];
    contentScripts: PluginContentScriptRegistration[];
}
declare function getCollectedSidebarFooterItems(registrations: object): readonly CollectedSidebarFooterItem[] | null;
/**
 * Run a plugin app definition against the canonical validating collector.
 * Both the Omnyo app and the public test harness use this implementation so a
 * registration accepted by one cannot be rejected or normalized differently
 * by the other.
 */
declare function collectPluginAppRegistrations(definition: PluginAppDefinition, onComposerCustomizationRejected?: (reason: string) => void): CollectedPluginAppRegistrations;

export { adaptSidebarFooterAction, collectPluginAppRegistrations, getCollectedSidebarFooterItems };
export type { CollectedCompatibilitySidebarFooterItem, CollectedExperimentalSidebarFooterItem, CollectedManagedSidebarFooterItem, CollectedPluginAppRegistrations, CollectedPluginCommandRegistration, CollectedPluginProviderIconRegistration, CollectedSidebarFooterItem, ExperimentalSidebarFooterCommandKind, ExperimentalSidebarFooterItemRuntime, ExperimentalSidebarFooterRuntimeSnapshot };
