// Portable type declarations for `@omnyo/plugin-sdk`. Private
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring another private workspace package.
//
// The upstream source is preserved for selected merge integration:
// and read the real source: https://github.com/get-bb/bb

import { ReactNode, ComponentType } from 'react';
import { RenderResult } from '@testing-library/react';
import { ExperimentalSidebarFooterItemRegistration, PluginProviderIconRegistration, PluginHomepageSectionRegistration, PluginSettingsSectionRegistration, ExperimentalAppOverlayRegistration, ExperimentalSidebarFooterCardRegistration, ExperimentalTitleBarCenterRegistration, ExperimentalSidebarEntryRegistration, PluginNavPanelRegistration, PluginThreadPanelActionRegistration, PluginNewThreadPanelActionRegistration, ComposerCustomization, PluginPendingInteractionRegistration, PluginSidebarFooterActionRegistration, PluginThreadListRegistration, PluginThreadHeaderActionRegistration, ExperimentalThreadCompanionRegistration, PluginThreadViewRegistration, PluginThreadActionRegistration, ExperimentalPluginBrowserToolbarActionRegistration, PluginFileOpenerRegistration, PluginSourceCodeRendererRegistration, PluginDiffRendererRegistration, PluginMessageDirectiveRegistration, ExperimentalCodeFenceRendererRegistration, PluginMessageActionRegistration, ExperimentalIconRegistration, PluginTimelineRendererRegistration, PluginEnvironmentProviderInputsRegistration, PluginMachineProviderInputsRegistration, PluginContentScriptRegistration, ComposerDraftSnapshot, PluginComposerScope, ComposerSelection, PluginComposerTextEffect, ExperimentalComposerSuggestion, PluginComposerMention, ComposerSubmitOptions, ExperimentalClipboardContent, PluginComposerThreadRowStatus, ExperimentalOpenFixedTabOptions, JsonValue as JsonValue$1, ExperimentalThreadRowSubtitle, experimental_AppNavigate, ExperimentalFileOpenOptions, PluginAppDefinition, PluginRpcContract, StandardSchemaV1InferInput, PluginRpcResult, experimental_PluginBrowserSdk, ExperimentalVisibleAppContext, PluginRealtimeConnectionState, ComposerMention, ComposerAttachment, PluginSdkApp, PluginSidebarThreadsState, PluginProvidersState, PluginCodeThemeState, BranchesState, CheckoutState, ExperimentalThreadGit, PluginSidebarPullRequest, PluginSidebarThreadRowStatus, PluginSidebarThreadShortcut, PluginSidebarSplitLayout, PluginThreadActionTarget, PluginThreadActionEntry, PluginThreadActionRegistrationInfo, PluginEnvironmentProvidersState } from '@omnyo/plugin-sdk';

type ThreadListIndicatorKind = "background-agent" | "background-command" | "callback-waiting" | "dependency-failed" | "draft" | "external" | "goal" | "input-welcome" | "none" | "open" | "plan-mode" | "queued-failed" | "queued-waiting" | "ready-to-archive" | "runtime" | "unread-error" | "unread-success" | "waiting-for-input" | "workflow" | "working-draft";

/**
 * A value that survives a JSON round trip without coercion or data loss.
 *
 * Host boundaries still validate values at runtime because TypeScript cannot
 * exclude non-finite numbers and plugin bundles can bypass static types.
 */
type JsonValue = string | number | boolean | null | JsonValue[] | {
    [key: string]: JsonValue;
};

/**
 * A name the host resolves to a glyph, in this order: a name any plugin
 * registered with `app.experimental_icons.register()`, then a built-in Omnyo icon
 * name (`"Zap"`), then a namespaced `"<pluginId>/<name>"` glyph naming an
 * entry of that plugin's manifest `omnyo.branding.experimental_icons` map. A
 * registration therefore shadows a built-in, and either shadows a declared
 * icon of the same name. Names that resolve to none of the three fall back to
 * the surface's generic icon.
 *
 * Declared icons and registrations are one vocabulary here: the same name
 * works in `experimental_Icon`, in every field below, and — for a declared
 * icon — in the tool, provider and bridge-row declarations that accept one.
 * Declared icons need no frontend bundle and survive the plugin being stopped;
 * registrations can be any React component but live only while the plugin's
 * app bundle is loaded.
 */
type IconName = string;
/**
 * The glyph mapped from the server-owned work summary. Read unreadness from
 * `isUnread` independently. Local drafts may decorate the glyph without
 * changing work state or archive eligibility.
 */
type PluginSidebarThreadIndicator = ThreadListIndicatorKind;
/** One project in the sidebar's live view. */
interface ExperimentalProjectSidebarMenuItem {
    id: string;
    label: string;
    icon?: IconName;
    destructive?: boolean;
    run(): void | Promise<void>;
}
interface ExperimentalProjectSidebarItem {
    id: string;
    label: string;
    icon: IconName;
    href: string;
    threadId?: string;
    status?: {
        icon: IconName;
        label: string;
    };
    indicator?: PluginSidebarThreadIndicator;
    count?: number;
    unread?: boolean;
    children?: readonly ExperimentalProjectSidebarItem[];
    onRename?: (label: string) => void | Promise<void>;
    onReorder?: (orderedChildIds: readonly string[]) => void | Promise<void>;
    onDrop?: (itemId: string) => void | Promise<void>;
    menuItems?: readonly ExperimentalProjectSidebarMenuItem[];
}
interface ExperimentalProjectSidebarGroup {
    /** Host-stamped owner identity; providers omit this field. */
    key?: string;
    projectId: string;
    items: readonly ExperimentalProjectSidebarItem[];
}
/**
 * Everything `@omnyo/plugin-sdk/app` resolves to at runtime. The Omnyo app builds
 * the real implementation and `satisfies` this interface; `omnyo plugin build`
 * shims the specifier to that object on `globalThis.__omnyoPluginRuntime`.
 */
type ExperimentalThreadBootstrapData = {
    status: "pending";
} | {
    status: "unavailable";
} | {
    status: "error";
    message: string;
    updatedAt: number;
} | {
    status: "ready";
    result: JsonValue;
    updatedAt: number;
    current: boolean;
};

type ExperimentalSidebarFooterCommandKind = "close" | "open" | "toggle";
interface ExperimentalSidebarFooterRuntimeSnapshot {
    command: {
        sequence: number;
        kind: ExperimentalSidebarFooterCommandKind;
    } | null;
}
interface ExperimentalSidebarFooterItemRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ExperimentalSidebarFooterRuntimeSnapshot;
    acknowledgeCommand(sequence: number): void;
}
type CollectedExperimentalSidebarFooterItem = ExperimentalSidebarFooterItemRegistration & {
    runtime: ExperimentalSidebarFooterItemRuntime;
};
type CollectedPluginProviderIconRegistration = Omit<PluginProviderIconRegistration, "providerKind"> & {
    providerKind: PluginProviderIconRegistration["providerKind"] | "all";
};

/**
 * `@omnyo/plugin-sdk/testing/app` — the frontend plugin test harness. Tests a
 * plugin's `app.tsx` source directly under vitest + jsdom, without the Omnyo
 * host or the esbuild bundle:
 *
 * - {@link installTestPluginRuntime} fills `globalThis.__omnyoPluginRuntime.
 *   pluginSdkApp` with a test implementation of the `@omnyo/plugin-sdk/app`
 *   surface (the same seam `omnyo plugin build` shims to the real app). The
 *   `@omnyo/plugin-sdk/app` exports look the runtime up when they are called
 *   or rendered, so import order does not matter: install the runtime any time
 *   before the first hook runs ({@link loadPluginApp} and {@link renderSlot}
 *   install it for you).
 * - {@link loadPluginApp} runs the definition's setup against a validating
 *   collector (ported from the Omnyo app's interpreter, same error messages)
 *   and returns the typed slot registrations.
 * - {@link renderSlot} mounts one registration's component with mock hook
 *   backends: rpc as a method→handler map with a call log, realtime as a
 *   channel you can push events into, settings/context as plain values, and
 *   navigate/composer as recorders. Its `behavior`, `inspection`, and
 *   `lifecycle` views separate host inputs, assertions, and mount controls;
 *   the existing direct members remain aliases.
 *
 * Add `// @vitest-environment jsdom` to test files using renderSlot.
 */
interface RpcCall {
    method: string;
    input: unknown;
}
/** One recorded `useSdk()` call, as `"<area>.<method>"` plus its arguments. */
interface SdkCall {
    method: string;
    args: unknown[];
}
type PluginSdkFakeTree<T> = {
    [Key in keyof T]?: T[Key] extends (...args: never[]) => unknown ? T[Key] : PluginSdkFakeTree<T[Key]>;
};
/**
 * Nested partial fakes for `useSdk()`, mirroring the client's areas and
 * sub-areas (`{ threads: { queuedMessages: { create } } }`). Provide only the
 * methods the slot calls; a call to anything else throws with the missing
 * dot-path so the test fails loudly instead of returning undefined.
 */
type PluginSdkTestFakes = PluginSdkFakeTree<experimental_PluginBrowserSdk>;
type NavigateCall = {
    method: "toThread";
    threadId: string;
    options?: Parameters<experimental_AppNavigate["toThread"]>[1];
} | {
    method: "experimental_prefetchThreadOpen";
    threadId: string;
} | {
    method: "toProject";
    projectId: string;
} | {
    method: "toPluginPanel";
    path: string;
    options?: {
        subPath?: string;
        replace?: boolean;
    };
} | {
    method: "toCompose";
    options?: Parameters<experimental_AppNavigate["toCompose"]>[0];
} | {
    method: "openThreadPanel";
    options: Parameters<experimental_AppNavigate["openThreadPanel"]>[0];
} | {
    method: "openUrl";
    url: string;
} | {
    method: "experimental_openFilePreview";
    options: ExperimentalFileOpenOptions;
} | {
    method: "experimental_openFileExternally";
    options: ExperimentalFileOpenOptions;
} | {
    method: "experimental_openTerminal";
    options: Parameters<experimental_AppNavigate["experimental_openTerminal"]>[0];
};
interface ExperimentalFixedTabOpenCall {
    surface: ExperimentalOpenFixedTabOptions<JsonValue$1>["surface"];
    panelId: string;
    tabId: string;
    target?: JsonValue$1;
}
interface ComposerLog {
    /** Latest plain text in this isolated composer scope. */
    readonly text: string;
    /**
     * Latest text and mention pills, as `useComposer().draft` reports them.
     * The harness composer has no caret, so cursor inserts land at the end.
     */
    readonly draft: ComposerDraftSnapshot;
    /** The key `useComposer().key` reports for the current scope. */
    readonly key: string;
    /** Latest host-provided composer scope. */
    readonly scope: PluginComposerScope;
    /** Current picker snapshot, or null for a composer without pickers. */
    readonly selection: ComposerSelection | null;
    /** Latest host-provided attachment count exposed through `useComposerView()`. */
    readonly attachmentCount: number;
    /** Latest host-rendered text effect requested by the plugin. */
    textEffect: PluginComposerTextEffect | null;
    textEffectCalls: Array<PluginComposerTextEffect | null>;
    /** Latest suggested next message the plugin asked the composer to show. */
    suggestion: ExperimentalComposerSuggestion | null;
    suggestionCalls: Array<ExperimentalComposerSuggestion | null>;
    /** Whether this plugin currently holds the composer input lock. */
    inputLocked: boolean;
    inputLockCalls: boolean[];
    quotes: string[];
    mentions: PluginComposerMention[];
    focusCount: number;
    /**
     * Every `submit` the plugin ran, in order. The harness composer has no
     * submit pipeline of its own, so it records the options and clears the
     * draft — enough to assert what a picker scheduled and that it tidied up.
     */
    submits: ComposerSubmitOptions[];
    /**
     * Every `setSelection` the harness composer accepted, in order. The
     * harness has no pickers of its own, so it merges accepted fields into
     * its current selection and returns that snapshot. A thread drops
     * project and environment because it has no pickers for them. The
     * queued-message scope rejects, as the app does.
     */
    selections: ComposerSelection[];
}
/**
 * The test stand-in for Omnyo's single undo history. `undo` and `redo` replay the
 * newest entry the way Cmd+Z and Cmd+Shift+Z do; the label lists are oldest
 * first.
 */
interface ExperimentalTestActionHistory {
    readonly undoLabels: string[];
    readonly redoLabels: string[];
    undo(): Promise<void>;
    redo(): Promise<void>;
}
/**
 * What `experimental_useThreadActions(thread)` returns in a test, in menu
 * order; the host's own actions are not emulated. `requestRename` is the
 * caller's rename editor (a no-op when it passed none), for entries whose
 * `run` renames. The fake applies `keys`. Omitted → an empty list. The fake
 * `experimental_ThreadActionsMenu` opens on a trigger click and the fake
 * context menu on right-click; each lists these entries and its `inline`
 * items as `menuitem` buttons, and closes after one runs (calling
 * `onOpenChange(false)` and `onCloseAutoFocus`).
 */
type TestThreadActionsResolver = (thread: PluginThreadActionTarget, options: {
    requestRename(threadId: string): void;
}) => readonly PluginThreadActionEntry[];
/** One recorded `experimental_useThreadGroupActions()` call. */
type ThreadGroupActionCall = {
    action: "group";
    threadIds: readonly string[];
} | {
    action: "rename";
    groupId: string;
    name: string;
} | {
    action: "ungroup";
    groupId: string;
} | {
    action: "move";
    threadId: string;
    groupId: string | null;
};
type TestClipboard = (content: ExperimentalClipboardContent) => Promise<boolean>;
/**
 * Install the test runtime at `globalThis.__omnyoPluginRuntime.pluginSdkApp`,
 * plus the React the `@omnyo/plugin-sdk/app` components render through.
 * Idempotent per module instance. Call it before the first SDK hook runs or
 * SDK component renders; when the plugin's modules are imported does not
 * matter.
 */
declare function installTestPluginRuntime(): void;
interface CapturedPluginApp {
    homepageSections: PluginHomepageSectionRegistration[];
    settingsSections: PluginSettingsSectionRegistration[];
    appOverlays: ExperimentalAppOverlayRegistration[];
    sidebarFooterCards: ExperimentalSidebarFooterCardRegistration[];
    titleBarCenters: ExperimentalTitleBarCenterRegistration[];
    sidebarEntries: ExperimentalSidebarEntryRegistration[];
    navPanels: PluginNavPanelRegistration[];
    threadPanelActions: PluginThreadPanelActionRegistration[];
    newThreadPanelActions: PluginNewThreadPanelActionRegistration[];
    composerCustomizations: ComposerCustomization[];
    pendingInteractions: PluginPendingInteractionRegistration[];
    sidebarFooterActions: PluginSidebarFooterActionRegistration[];
    experimentalSidebarFooterItems: CollectedExperimentalSidebarFooterItem[];
    threadLists: PluginThreadListRegistration[];
    threadHeaderActions: PluginThreadHeaderActionRegistration[];
    threadCompanions: ExperimentalThreadCompanionRegistration[];
    threadViews: PluginThreadViewRegistration[];
    threadActions: PluginThreadActionRegistration<unknown>[];
    browserToolbarActions: ExperimentalPluginBrowserToolbarActionRegistration[];
    fileOpeners: PluginFileOpenerRegistration[];
    sourceCodeRenderers: PluginSourceCodeRendererRegistration[];
    diffRenderers: PluginDiffRendererRegistration[];
    messageDirectives: PluginMessageDirectiveRegistration[];
    codeFenceRenderers: ExperimentalCodeFenceRendererRegistration[];
    messageActions: PluginMessageActionRegistration[];
    providerIcons: CollectedPluginProviderIconRegistration[];
    icons: ExperimentalIconRegistration[];
    timelineRenderers: PluginTimelineRendererRegistration[];
    environmentProviderInputs: PluginEnvironmentProviderInputsRegistration[];
    machineProviderInputs: PluginMachineProviderInputsRegistration[];
    contentScripts: PluginContentScriptRegistration[];
}
type PluginAppModule = {
    default: unknown;
};
type PluginAppSource = PluginAppDefinition | PluginAppModule | (() => Promise<PluginAppDefinition | PluginAppModule>);
/**
 * Install the test runtime, resolve the plugin app definition, and capture
 * its slot registrations. Pass the imported module, its default export, or a
 * thunk (`() => import("../app.tsx")`).
 */
declare function loadPluginApp(source: PluginAppSource): Promise<CapturedPluginApp>;
interface ContentScriptTestMountOptions {
    pluginId: string;
    /** Defaults to 1. Pass the host generation you want the plugin to observe. */
    generation?: number;
    /**
     * Simulate an older compatible host that predates the optional experimental
     * thread-row status API. Current-host behavior is enabled by default.
     */
    omitExperimentalThreadRowStatus?: boolean;
    /** Simulate a host that predates sidebar subtitles. */
    omitExperimentalThreadRowSubtitle?: boolean;
    /**
     * Host result for `experimental_copyToClipboard()` writes, which are
     * recorded in `inspection.experimental_clipboardWrites` until another
     * mount or `renderSlot` takes the clipboard. Omitted → every write
     * succeeds.
     */
    experimental_copyToClipboard?: TestClipboard;
}
interface ContentScriptThreadRowStatusCall {
    threadId: string;
    status: PluginComposerThreadRowStatus | null;
}
interface MountedPluginContentScripts {
    inspection: {
        readonly mountedIds: readonly string[];
        readonly signal: AbortSignal;
        readonly disposed: boolean;
        readonly threadRowStatusCalls: readonly ContentScriptThreadRowStatusCall[];
        getThreadRowStatus(threadId: string): PluginComposerThreadRowStatus | null;
        readonly experimental_threadRowSubtitleCalls: readonly {
            threadId: string;
            subtitle: ExperimentalThreadRowSubtitle | null;
        }[];
        experimental_getThreadRowSubtitle(threadId: string): ExperimentalThreadRowSubtitle | null;
        /** Every `experimental_copyToClipboard()` write, in order. */
        readonly experimental_clipboardWrites: readonly ExperimentalClipboardContent[];
    };
    lifecycle: {
        /** Abort, then run returned cleanup functions once in reverse order. */
        dispose(): Promise<void>;
    };
}
/**
 * Mount captured content scripts with host-faithful ordering and rollback.
 * Call this once per simulated app window; each result owns an independent
 * AbortSignal and cleanup lifecycle.
 */
declare function mountPluginContentScripts(app: CapturedPluginApp, options: ContentScriptTestMountOptions): Promise<MountedPluginContentScripts>;
type PluginRpcTestHandlers<Contract extends PluginRpcContract> = {
    [Method in keyof Contract]: (input: StandardSchemaV1InferInput<Contract[Method]["input"]>) => PluginRpcResult<Contract[Method]> | Promise<PluginRpcResult<Contract[Method]>>;
};
interface RenderSlotOptions<Contract extends PluginRpcContract = PluginRpcContract> {
    /**
     * Backing handlers for `useRpc().call`: method name → implementation.
     * Inputs and results are JSON-round-tripped like the wire; a method
     * without a handler rejects, and a throwing handler rejects with its
     * message (what the real rpc client surfaces).
     */
    rpc?: PluginRpcTestHandlers<Contract>;
    /** Thread and method keys use `${threadId}:${method}`. Values come from the conversation bootstrap. */
    threadBootstrapData?: Readonly<Record<string, ExperimentalThreadBootstrapData>>;
    /** `useSettings()` values; omitted → `{ values: undefined, isLoading: false }`. */
    settings?: Record<string, string | number | boolean>;
    /** `experimental_useAppContext()` selection; both default to null. */
    context?: {
        projectId?: string | null;
        threadId?: string | null;
    };
    visibleContext?: ExperimentalVisibleAppContext;
    /** `experimental_usePluginId()` value; defaults to `test-plugin`. */
    pluginId?: string;
    /** Initial `useRealtimeConnectionState()` value; defaults to `connected`. */
    realtimeConnectionState?: PluginRealtimeConnectionState;
    /** Initial state for this render's isolated composer scope and view. */
    composer?: {
        text?: string;
        /** Mention pills already in `text`, with ranges into it. */
        mentions?: readonly ComposerMention[];
        scope?: PluginComposerScope;
        attachmentCount?: number;
        attachments?: readonly ComposerAttachment[];
        layout?: "compact" | "expanded";
        isRunning?: boolean;
        isSubmitting?: boolean;
        selection?: ComposerSelection;
        /**
         * What `submittingBlockedReason` reports, and what `submit` rejects
         * with. Omitted → "Type a message first." while the draft is empty,
         * "Submitting..." while `isSubmitting`, otherwise null.
         */
        submittingBlockedReason?: string | null;
    };
    /**
     * Threads and projects `experimental_useSidebarThreads()` reports. Omitted →
     * a ready, empty list. Pass `{ status: "loading" }` to test that branch.
     */
    inboxSnapshot?: Partial<ReturnType<PluginSdkApp["experimental_useInboxSnapshot"]>>;
    projectSidebarItems?: readonly ExperimentalProjectSidebarGroup[];
    sidebarThreads?: Partial<PluginSidebarThreadsState>;
    /** The chats `experimental_useChatSelection()` starts with. Omitted → none. */
    experimental_chatSelection?: readonly string[];
    experimental_threadWork?: Readonly<Record<string, ReturnType<PluginSdkApp["experimental_useThreadWork"]>>>;
    /**
     * The provider directory `experimental_useProviders()` reports. Omitted →
     * a ready, empty list. Pass `{ status: "loading" }` to test that branch.
     */
    providers?: Partial<PluginProvidersState>;
    /**
     * The code theme `experimental_useCodeTheme()` reports. Omitted → a light
     * mode with no resolved document, the state a plugin sees on first paint.
     */
    codeTheme?: Partial<PluginCodeThemeState>;
    /**
     * Host result for `experimental_copyToClipboard()` writes, which are
     * recorded in `inspection.experimental_clipboardWrites` either way. The
     * clipboard is not slot-scoped: writes from anywhere (components, command
     * callbacks) go to the most recently rendered slot or mounted content
     * scripts. Omitted → every write succeeds.
     */
    experimental_copyToClipboard?: TestClipboard;
    branchesState?: Partial<BranchesState>;
    /** Checkout facts `experimental_useCheckoutState()` reports. */
    checkoutState?: Partial<CheckoutState>;
    /**
     * What `experimental_useThreadGit()` reports. Omitted → null, a thread
     * without a git workspace. The fake `experimental_ThreadMergeBasePicker`
     * renders a button with `data-testid="Omnyo-thread-merge-base-picker"`.
     */
    threadGit?: ExperimentalThreadGit | null;
    /**
     * Pull requests `experimental_useSidebarThreadPullRequest()` reports, keyed
     * by thread id. Omitted → every thread reports none.
     */
    sidebarPullRequests?: Record<string, PluginSidebarPullRequest>;
    /**
     * Thread ids `useSidebarThreadDraft()` and `useSidebarThreadDraftIds()`
     * report as holding an unsent draft. Omitted → none.
     */
    sidebarDraftThreadIds?: readonly string[];
    /**
     * Row statuses `useSidebarThreadRowStatus()` reports, keyed by thread id.
     * Omitted → every thread reports null.
     */
    sidebarRowStatuses?: Record<string, PluginSidebarThreadRowStatus>;
    /**
     * Shortcuts `useSidebarThreadShortcut()` reports, keyed by thread id, as
     * if the app command modifier were held. Omitted → every thread reports
     * null.
     */
    sidebarShortcuts?: Record<string, PluginSidebarThreadShortcut>;
    /**
     * The split layout `useSidebarSplitLayout()` reports, and the source of each
     * thread's `experimental_useSidebarThreadSplit().layout`. Omitted → null.
     */
    sidebarSplitLayout?: PluginSidebarSplitLayout;
    /**
     * What `experimental_useThreadActions()` reports for a thread, in menu
     * order. Omitted → an empty list.
     */
    threadActions?: TestThreadActionsResolver;
    /**
     * What `experimental_useThreadActionRegistrations()` reports. Omitted → an
     * empty list.
     */
    threadActionRegistrations?: readonly PluginThreadActionRegistrationInfo[];
    /**
     * The environment provider catalog `useEnvironmentProviders()` reports.
     * Omitted → a ready, empty list. Pass `{ status: "loading" }` to test that
     * branch.
     */
    environmentProviders?: Partial<PluginEnvironmentProvidersState>;
    /**
     * Fakes for `useSdk()`, one partial object per area. Calls are recorded
     * in `inspection.sdkCalls`; a call to a method you did not provide throws.
     */
    sdk?: PluginSdkTestFakes;
    /** Host acceptance for `experimental_useAppNavigate().openThreadPanel`. */
    openThreadPanel?: (options: Parameters<experimental_AppNavigate["openThreadPanel"]>[0]) => boolean;
    /** Host acceptance for URL intents from the hook or `UrlLink`. */
    openUrl?: (url: string) => boolean;
    /** Host acceptance for preview intents from the hook or file link. */
    openFilePreview?: (options: ExperimentalFileOpenOptions) => boolean;
    /** Host acceptance for preferred-external file intents. */
    openFileExternally?: (options: ExperimentalFileOpenOptions) => boolean;
    /** Host acceptance for `experimental_useAppNavigate().experimental_openTerminal`. */
    openTerminal?: (options: Parameters<experimental_AppNavigate["experimental_openTerminal"]>[0]) => boolean;
    /** Host acceptance for an owner-scoped fixed-tab selection. */
    experimental_openFixedTab?: (call: ExperimentalFixedTabOpenCall) => boolean;
    /** Initial session target visible to `experimental_useFixedTabTarget`. */
    experimental_fixedTabTarget?: {
        panelId: string;
        tabId: string;
        target: JsonValue$1;
    };
}
/** Host-originated inputs a slot test can drive deterministically. */
interface RenderedSlotBehaviorDrivers {
    /**
     * Push a realtime event to `useRealtime(channel, …)` subscribers, wrapped
     * in act. The payload is JSON-round-tripped like `api.realtime.publish`.
     */
    emitRealtime(channel: string, payload: unknown): Promise<void>;
    /** Drive the lifecycle of the same connection used by realtime events. */
    setRealtimeConnectionState(state: PluginRealtimeConnectionState): Promise<void>;
    /** Replace composer text as a host-originated edit, wrapped in act. */
    setComposerText(text: string): Promise<void>;
    /** Replace the scope snapshots returned by composer hooks, wrapped in act. */
    setComposerScope(scope: PluginComposerScope): Promise<void>;
}
/** Read-only call/write logs produced while the slot is mounted. */
interface RenderedSlotInspectionState {
    /** Every `useRpc().call`, in order. */
    readonly rpcCalls: RpcCall[];
    /** Every `experimental_useAppNavigate()` call, in order. */
    readonly navigateCalls: NavigateCall[];
    /** Every validated `experimental_useAppPanel().openFixedTab` call. */
    readonly experimental_fixedTabOpenCalls: ExperimentalFixedTabOpenCall[];
    /** Entries recorded through `experimental_useActionHistory()`, with Cmd+Z / Cmd+Shift+Z drivers. */
    readonly experimental_actionHistory: ExperimentalTestActionHistory;
    /** Every `experimental_setChatSelection()` write, in order. */
    readonly experimental_chatSelectionWrites: (readonly string[])[];
    /** Every `experimental_useThreadGroupActions()` call, in order. */
    readonly experimental_threadGroupActionCalls: ThreadGroupActionCall[];
    /**
     * The environment id of every `experimental_useArchiveEnvironmentThreads()`
     * call, in order.
     */
    readonly experimental_environmentArchiveCalls: string[];
    /** Every `useSdk()` call, in order, as `"<area>.<method>"`. */
    readonly sdkCalls: SdkCall[];
    /** Every `experimental_copyToClipboard()` write, in order. */
    readonly experimental_clipboardWrites: ExperimentalClipboardContent[];
    /** Everything written through `useComposer()`. */
    readonly composer: ComposerLog;
}
/** Explicit mount controls, separate from behavior inputs and call logs. */
interface RenderedSlotLifecycleControls {
    rerender(ui: ReactNode): void;
    unmount(): void;
}
/**
 * Testing Library result plus Omnyo-specific helpers. Direct members are
 * retained for compatibility; named views make intent explicit in new tests.
 */
interface RenderedSlot extends RenderResult, RenderedSlotBehaviorDrivers, RenderedSlotInspectionState {
    readonly behavior: RenderedSlotBehaviorDrivers;
    readonly inspection: RenderedSlotInspectionState;
    readonly lifecycle: RenderedSlotLifecycleControls;
}
declare function renderSlot<Props extends object, Contract extends PluginRpcContract = PluginRpcContract>(registration: {
    component: ComponentType<Props>;
}, props: Props, options?: RenderSlotOptions<Contract>): RenderedSlot;

export { installTestPluginRuntime, loadPluginApp, mountPluginContentScripts, renderSlot };
export type { CapturedPluginApp, ComposerLog, ContentScriptTestMountOptions, ContentScriptThreadRowStatusCall, ExperimentalFixedTabOpenCall, ExperimentalTestActionHistory, MountedPluginContentScripts, NavigateCall, PluginAppSource, PluginRpcTestHandlers, PluginSdkTestFakes, RenderSlotOptions, RenderedSlot, RenderedSlotBehaviorDrivers, RenderedSlotInspectionState, RenderedSlotLifecycleControls, RpcCall, SdkCall, TestThreadActionsResolver, ThreadGroupActionCall };
